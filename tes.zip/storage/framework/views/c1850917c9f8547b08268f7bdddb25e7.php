
<?php $__env->startSection('container'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<a href="/admin" class="btn btn-primary mb-2">Kembali</a>

<div class="row">
    <div class="col-lg-12 d-flex align-items-stretch">
      <div class="card w-100">
        <div class="card-header">
            <h3 class="card-title mt-2">Edit User</h3>
        </div>
        <form action="/api/admin/<?php echo e($user->id); ?>" method="POST">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Nama" value="<?php echo e(old('name', $user->name)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="nama_barang">Email</label>
                <input type="text" class="form-control" id="email" name="email" placeholder="email" value="<?php echo e(old('email', $user->email)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="New Password" value="<?php echo e(old('password')); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="user_type">User Type</label>
                <select class="custom-select form-control" name="user_type" id="user_type">
                    <?php if($user->user_type == 'owner'): ?>
                    <option value="owner" <?php echo e($user->user_type == 'owner' ? 'selected' : ''); ?>>Owner</option>
                    <?php else: ?>
                    <option value="admin" <?php echo e($user->user_type == 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="karyawan" <?php echo e($user->user_type == 'karyawan' ? 'selected' : ''); ?>>Karyawan</option>
                    <?php endif; ?>
                </select>
            </div>           
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-warning">Submit</button>
        </div>
        </form>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HANWILL\STMIK\KP\pondokmawar\resources\views/pages/editadmin.blade.php ENDPATH**/ ?>