

  <footer class="main-footer text-center">
    <p>Copyright &copy; 2022 - Hanwill</p>
  </footer><?php /**PATH E:\HANWILL\STMIK\KP\pondokmawar\resources\views/components/footer.blade.php ENDPATH**/ ?>