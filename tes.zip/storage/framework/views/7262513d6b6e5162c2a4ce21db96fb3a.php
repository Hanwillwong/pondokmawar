<!-- Sidebar Start -->
<aside class="left-sidebar" style="width: 220px;">
    <!-- Sidebar scroll-->
      <div class="brand-logo d-flex align-items-center justify-content-between">
          <p class="fs-4 mt-4">
            <b>Pondok Mawar</b>
          </p>
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse" style="margin-top: -20px; margin-right: -10px;">
            <i class="bi bi-x"></i>
          </div>
          
        
      </div>
      <!-- Sidebar navigation-->
      <nav class="sidebar-nav" data-simplebar="">
        <ul id="sidebarnav" style="margin-left: -20px; margin-right: 10px;">
          <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">Product</span>
          </li> 
        <?php if(Gate::check('admin') || Gate::check('owner')): ?>
          <li class="sidebar-item">
            <a class="sidebar-link text-decoration-none" href="/product/create" aria-expanded="false">
              <span>
                <i class="bi bi-clipboard-plus"></i>
              </span>
              <span class="hide-menu">Tambah Barang</span>
            </a>
          </li>
          
        <?php endif; ?>
          <li class="sidebar-item">
            <a class="sidebar-link text-decoration-none" href="/product" aria-expanded="false">
              <span>
                <i class="bi bi-clipboard"></i>
              </span>
              <span class="hide-menu">List Barang</span>
            </a>
          </li>
        <?php if(Gate::check('admin') || Gate::check('owner')): ?>
        <li class="sidebar-item">
          <a class="sidebar-link text-decoration-none" href="/satuan/create" aria-expanded="false">
            <span>
              <i class="bi bi-tag"></i>
            </span>
            <span class="hide-menu">Tambah Satuan</span>
          </a>
        </li>
          <li class="sidebar-item">
            <a class="sidebar-link text-decoration-none" href="/satuan" aria-expanded="false">
              <span>
                <i class="bi bi-tags"></i>
              </span>
              <span class="hide-menu">List Satuan</span>
            </a>
          </li>
        <?php endif; ?>
        <?php if(Gate::check('owner')): ?>
          <li class="nav-small-cap">
            <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
            <span class="hide-menu">AUTH</span>
          </li>
          <li class="sidebar-item">
            <a class="sidebar-link text-decoration-none" href="/admin" aria-expanded="false">
              <span>
                <i class="bi bi-person-plus"></i>
              </span>
              <span class="hide-menu">User</span>
            </a>
          </li>
        <?php endif; ?>
          <hr width="90%">
          <li class="sidebar-item">
            <i class="bi bi-person-circle fa-lg"></i>
            <strong><?php echo e(auth()->user()->name); ?></strong>
          </li>
          <hr width="90%">
          <form action="<?php echo e(url('/api/logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger justify-content-center d-flex" type="submit">Logout</button>
          </form>
        </ul>
      </nav>
      <!-- End Sidebar navigation -->
      <!-- End Sidebar scroll-->
  </aside><?php /**PATH E:\HANWILL\STMIK\KP\pondokmawar\resources\views/components/sidebar.blade.php ENDPATH**/ ?>