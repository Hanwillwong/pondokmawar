 <!--  Header Start -->
 <header class="app-header">
    <nav class="navbar navbar-expand-lg navbar-light">
      <ul class="navbar-nav">
        <li class="nav-item d-block d-xl-none" style="margin-left: -35px">
          <a class="nav-link sidebartoggler nav-icon-hover" id="headerCollapse" href="javascript:void(0)">
            <i class="bi bi-list"></i>  
          </a>
        </li>
        
      </ul>
      
    </nav>
  </header><?php /**PATH E:\HANWILL\STMIK\KP\pondokmawar\resources\views/components/navbar.blade.php ENDPATH**/ ?>