
<?php $__env->startSection('container'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<a href="/product" class="btn btn-primary mb-2">Kembali</a>

<div class="row">
    <div class="col-lg-12 d-flex align-items-stretch">
      <div class="card w-100">
        <div class="card-header">
            <h3 class="card-title mt-2">Edit Barang</h3>
        </div>
        <form action="/api/product/<?php echo e($product->id); ?>" method="POST">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="form-group">
                <label for="nama_barang">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang <?php $__errorArgs = ['nama_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_barang" placeholder="Nama Barang" value="<?php echo e(old('nama_barang', $product->nama_barang)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="merk">Merk</label>
                <input type="text" class="form-control <?php $__errorArgs = ['merk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="merk" name="merk" placeholder="Merk" value="<?php echo e(old('merk', $product->merk)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="supplier">Supplier</label>
                <input type="text" class="form-control <?php $__errorArgs = ['suppluer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="supplier" id="supplier" placeholder="Supplier" value="<?php echo e(old('supplier', $product->supplier)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="satuanid">Satuan</label>
                <select class="custom-select form-control" name="satuanid" id="satuanid">
                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('satuanid', $product->satuanid)==$satuan->id): ?>
                            <option value="<?php echo e($satuan->id); ?>" selected><?php echo e($satuan->nama); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($satuan->id); ?>"><?php echo e($satuan->nama); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </select>
            </div>
            <div class="form-group mt-3">
                <label for="harga_beli">Harga Beli</label>
                <input type="number" class="form-control <?php $__errorArgs = ['harga_beli'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="harga_beli" id="harga_beli" placeholder="Harga Beli" value="<?php echo e(old('harga_beli', $product->harga_beli)); ?>">
            </div>
            <div class="form-group mt-3">
                <label for="harga_jual">Harga Jual</label>
                <input type="number" class="form-control <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="harga_jual" id="harga_jual" placeholder="Harga Jual" value="<?php echo e(old('harga_jual', $product->harga_jual)); ?>">
            </div>
            
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-warning">Submit</button>
        </div>
        </form>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\HANWILL\STMIK\KP\pondokmawar\resources\views/pages/editproduct.blade.php ENDPATH**/ ?>